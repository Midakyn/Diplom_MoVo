<?php
// Text
$_['text_footer'] 	= '<a href="https://www.opencart.com/">OpenCart</a> &copy; 2009-' . date('Y') . ' Всі права захищені.';
$_['text_version']  = '<div class="alert">
  <i class="fa fa-download"></i> Магазин модулів для 
  <a target="_blank" href="https://ocmod.net/ua/moduli/"> Opencart %s <i class="fa fa-external-link"></i></a>
  <br><i class="fa fa-support"></i> Технічна підтримка <b>OCMOD.NET</b> у 
  <a target="_blank" href="tg://resolve?domain=OcmodConsultantBot"> Telegram <i class="fa fa-external-link"></i></a>
</div>';

