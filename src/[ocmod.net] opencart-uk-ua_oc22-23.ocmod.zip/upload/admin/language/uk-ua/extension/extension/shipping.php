<?php
// Heading
$_['heading_title'] = 'Доставка';

// Text
$_['text_success'] = 'Налаштування успішно оновлені!';
$_['text_list'] = 'Список способів доставки';

// Column
$_['column_name'] = 'Спосіб доставки';
$_['column_status'] = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для управління доставкою!';