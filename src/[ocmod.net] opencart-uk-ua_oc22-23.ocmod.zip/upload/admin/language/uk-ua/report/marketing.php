<?php
// Heading
$_['heading_title'] = 'Звіт з маркетингових акціях';

// Text
$_['text_list'] = 'Список акцій';
$_['text_all_status'] = 'Всі статуси';

// Column
$_['column_campaign'] = 'Назва акції';
$_['column_code'] = 'Код';
$_['column_clicks'] = 'Переходів';
$_['column_orders'] = 'Кількість замовлень';
$_['column_total'] = 'Разом';

// Entry
$_['entry_date_start'] = 'Дата';
$_['entry_date_end'] = 'Дата закінчення';
$_['entry_status'] = 'Статус замовлення';