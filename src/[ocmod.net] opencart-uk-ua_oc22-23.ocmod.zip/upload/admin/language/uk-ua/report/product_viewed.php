<?php
// Heading
$_['heading_title'] = 'Звіт по переглянутих товарів';

// Text
$_['text_list'] = 'Переглянуті товари';
$_['text_success'] = 'Список переглянутих товарів очищений!';

// Column
$_['column_name'] = 'Назва товару';
$_['column_model'] = 'Модель';
$_['column_viewed'] = 'Переглядів';
$_['column_percent'] = 'Відсоток';

// Error
$_['error_permission'] = 'У Вас немає прав для змін!';