<?php
// Text
$_['text_title'] = 'Доставка по місту';
$_['text_weight'] = 'Вага:';