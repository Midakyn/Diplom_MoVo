<?php
// Text
$_['text_title'] = 'Продам';
$_['text_description'] = 'Самовивіз із магазину';