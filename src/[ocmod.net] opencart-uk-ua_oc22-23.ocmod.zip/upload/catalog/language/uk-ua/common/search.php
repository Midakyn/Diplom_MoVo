<?php
// Text
$_['text_search'] = 'Пошук';

