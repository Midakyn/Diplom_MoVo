<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title'] = 'Аналітика продажів';

// Text
$_['text_order']    = 'Замовлення';
$_['text_customer'] = 'Покупці';
$_['text_day']      = 'Сьогодні';
$_['text_week']     = 'Тиждень';
$_['text_month']    = 'Місяць';
$_['text_year']     = 'Рік';