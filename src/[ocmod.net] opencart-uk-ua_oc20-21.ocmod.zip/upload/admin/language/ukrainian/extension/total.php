<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Оформлення замовлення';

// Text
$_['text_success']      = 'Ви успішно змінили Оформлення замовлення!';
$_['text_list']         = 'Список змінних оформлення замовлення';

// Column
$_['column_name']       = 'Змінна вартості замовлення';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action']     = 'Дія';

// Error
$_['error_permission']  = 'У Вас немає доступу для зміни оформлення замовлення!';