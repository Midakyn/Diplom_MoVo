<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Модулі';

// Text
$_['text_success']     = 'Ви успішно змінили модулі!';
$_['text_layout']      = 'Після успішного встановлення і налаштування модулю Ви можете додати його до макетів<a href="%s" class="alert-link">тут</a>!';
$_['text_list']        = 'Список модулів';

// Column
$_['column_name']      = 'Назва модулю';
$_['column_action']    = 'Дія';

// Error
$_['error_permission'] = 'У вас немає доступу до зміни модулів!';