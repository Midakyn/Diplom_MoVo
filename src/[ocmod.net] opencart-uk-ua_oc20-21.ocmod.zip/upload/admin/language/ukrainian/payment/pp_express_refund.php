<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']					= 'Повернення грошей';

// Text
$_['text_pp_express']				= 'PayPal Express оформлення';
$_['text_current_refunds']			= 'Відшкодування цих транзакцій вже проведено. Максимальне відшкодування становить';

// Entry
$_['entry_transaction_id']			= 'Номер транзакції';
$_['entry_full_refund']				= 'Повне відшкодування';
$_['entry_amount']					= 'Сума';
$_['entry_message']					= 'Повідомлення';

// Button
$_['button_refund']					= 'Провести повернення';

// Error
$_['error_partial_amt']				= 'Необхідно вказати суму часткового повернення';
$_['error_data']					= 'Відсутні дані запиту';