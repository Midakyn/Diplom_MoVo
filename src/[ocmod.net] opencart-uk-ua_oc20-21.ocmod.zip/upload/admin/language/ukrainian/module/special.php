<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Спеціальні пропозиції';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Ви успішно змінили модуль Спеціальні пропозиці!';
$_['text_edit']        = 'Змінити модуль Спеціальні пропозиції';

// Entry
$_['entry_limit']      = 'Обмеження';
$_['entry_image']      = 'Зображення (Ш x В) і зміна розміру';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Висота';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає доступу до зміни модулю Спеціальні пропозиції!';
$_['error_image']      = 'Необхідно вазати ширину і висоту зображення!';