<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Кнопка платежів Amazon';

$_['text_module']      = 'Модулі';
$_['text_success']     = 'Ви успішно змінили модуль Кнопки платежів Amazon!';
$_['text_edit']        = 'змінити модуль Кнопки платежів Amazon';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас немає доступу для зміни модулю кнопки платежів Amazon!';