<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Купон';

// Text
$_['text_total']       = 'Замовлення загалом';
$_['text_success']     = 'Ви успішно змінили Всього купонів!';
$_['text_edit']        = 'Змінити купон';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'У Вас немає доступу до зміни Всього купонів!';