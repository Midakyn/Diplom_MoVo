<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_approve_subject']      = '%s - Ваш партнерський рахунок активовано!';
$_['text_approve_welcome']      = 'Ласкаво просимо і дякуємо за реєстрацію в %s!';
$_['text_approve_login']        = 'Ваш обліковий запис створено і зараз Ви можете зайти використавши свій email і пароль через наш сайт або за посиланням:';
$_['text_approve_services']     = 'Після входу на сайт Ви зможете створювати трек-коди, відслідковувати комісійні платежі і змінювати свій обліковий запис.';
$_['text_approve_thanks']       = 'Дякуємо,';
$_['text_transaction_subject']  = '%s - Партнерська комісія';
$_['text_transaction_received'] = 'Ви отримали %s комісійних!';
$_['text_transaction_total']    = 'Загальна кількість Ваших комісійних виплат зараз становить %s.';