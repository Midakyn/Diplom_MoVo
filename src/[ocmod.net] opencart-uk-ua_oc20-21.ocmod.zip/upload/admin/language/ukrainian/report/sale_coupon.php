<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Звіт про купони';

// Text
$_['text_list']        = 'Список купонів';

// Column
$_['column_name']      = 'Назва купону';
$_['column_code']      = 'Код';
$_['column_orders']    = 'Замовлення';
$_['column_total']     = 'Загалом';
$_['column_action']    = 'Дія';

// Entry
$_['entry_date_start'] = 'Дата початку';
$_['entry_date_end']   = 'Дата закінчення';