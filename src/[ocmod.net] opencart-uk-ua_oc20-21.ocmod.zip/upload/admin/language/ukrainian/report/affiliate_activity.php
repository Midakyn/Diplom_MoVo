<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Звіт з активності партнерів';

// Text
$_['text_list']         = 'Список активностей партнерів';
$_['text_edit']         = '<a href="affiliate_id=%d">%s</a> змінили деталі облікового запису.';
$_['text_forgotten']    = '<a href="affiliate_id=%d">%s</a> запросили новий пароль.';
$_['text_login']        = '<a href="affiliate_id=%d">%s</a> увійшли.';
$_['text_password']     = '<a href="affiliate_id=%d">%s</a> змінили пароль облікового запису партнерської програми';
$_['text_payment']      = '<a href="affiliate_id=%d">%s</a> змінили свої платіжні деталі.';
$_['text_register']     = '<a href="affiliate_id=%d">%s</a> зареєстрували обліковий запис.';

// Column
$_['column_affiliate']  = 'Партнер';
$_['column_comment']    = 'Коментарій';
$_['column_ip']         = 'IP';
$_['column_date_added'] = 'Дата додавання';

// Entry
$_['entry_affiliate']   = 'Партнер';
$_['entry_ip']          = 'IP';
$_['entry_date_start']  = 'Дата початку';
$_['entry_date_end']    = 'Дата закінчення';