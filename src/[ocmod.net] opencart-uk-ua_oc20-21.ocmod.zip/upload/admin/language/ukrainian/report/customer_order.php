<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']         = 'Звіт про замовлення клієнтів';

// Text
$_['text_list']             = 'Список замовлень клієнтів';
$_['text_all_status']       = 'Всі статуси';

// Column
$_['column_customer']       = 'Ім’я покупця';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Група покупця';
$_['column_status']         = 'Статус';
$_['column_orders']         = 'Кількість замовлень';
$_['column_products']       = 'Кількість товарів';
$_['column_total']          = 'Загалом';
$_['column_action']         = 'Дія';

// Entry
$_['entry_date_start']      = 'Дата початку';
$_['entry_date_end']        = 'Дата закінчення';
$_['entry_status']          = 'Статус замовлення';