<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Звіт про доставки';

// Text
$_['text_list']         = 'Список доставок';
$_['text_year']         = 'Роки';
$_['text_month']        = 'Місяці';
$_['text_week']         = 'Тижні';
$_['text_day']          = 'Дні';
$_['text_all_status']   = 'Всі статуси';

// Column
$_['column_date_start'] = 'Дата початку';
$_['column_date_end']   = 'Дата закінчення';
$_['column_title']      = 'Назва доставки';
$_['column_orders']     = 'Кількість замовлень';
$_['column_total']      = 'Загалом';

// Entry
$_['entry_date_start']  = 'Дата початку';
$_['entry_date_end']    = 'Дата закінчення';
$_['entry_group']       = 'Сортувати за';
$_['entry_status']      = 'Статус замовлення';