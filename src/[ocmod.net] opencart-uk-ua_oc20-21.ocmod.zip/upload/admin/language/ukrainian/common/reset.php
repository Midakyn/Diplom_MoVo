<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// header
$_['heading_title']  = 'Змінити пароль';

// Text
$_['text_reset']     = 'Змінити пароль!';
$_['text_password']  = 'Введіть новий пароль.';
$_['text_success']   = 'Ваш пароль успішно змінено.';

// Entry
$_['entry_password'] = 'Пароль';
$_['entry_confirm']  = 'Підтвердити';

// Error
$_['error_password'] = 'Пароль повинен містити від 5 до 20 символів!';
$_['error_confirm']  = 'Пароль і підтвердження не співпадають!';