<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']                = 'Панель керування';

// Text
$_['text_order_total']             = 'Загальна кількість замовлень';
$_['text_customer_total']          = 'Загальна кількість покупців';
$_['text_sale_total']              = 'Загальна кількість продажів';
$_['text_online_total']            = 'Користувачів на сайті';
$_['text_map']                     = 'Карта світу';
$_['text_sale']                    = 'Аналіз продажів';
$_['text_activity']                = 'Остання активність';
$_['text_recent']                  = 'Останні замовлення';
$_['text_order']                   = 'Замовлення';
$_['text_customer']                = 'Покупці';
$_['text_day']                     = 'Сьогодні';
$_['text_week']                    = 'Цього тижня';
$_['text_month']                   = 'Цього місяця';
$_['text_year']                    = 'Цього року';
$_['text_view']                    = 'Подивитися більше...';

// Error
$_['error_install']                = 'УВАГА: Тека "Install" все ще існує! Її необхідно видалити з міркувань безпеки!';