<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']        = 'OpenCart';

// Text
$_['text_order']           = 'Замовлення';
$_['text_order_status']    = 'Обробляється';
$_['text_complete_status'] = 'Завершене';
$_['text_customer']        = 'Покупці';
$_['text_online']          = 'Користувачів на сайті';
$_['text_approval']        = 'Очікує підтвердження';
$_['text_product']         = 'Товарів';
$_['text_stock']           = 'Немає в наявності';
$_['text_review']          = 'Огляди';
$_['text_return']          = 'Повернення';
$_['text_affiliate']       = 'Партнери';
$_['text_store']           = 'Магазини';
$_['text_front']           = 'Вітрина';
$_['text_help']            = 'Допомога';
$_['text_homepage']        = 'Головна сторінка';
$_['text_support']         = 'Форум підтримки';
$_['text_documentation']   = 'Документація';
$_['text_logout']          = 'Вихід';