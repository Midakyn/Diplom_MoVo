<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Заблоковані IP';

// Text
$_['text_success']     = 'Ви успішно змінили заблоковані IP!';
$_['text_list']        = 'Список заблокованих IP';
$_['text_add']         = 'Додати IP до списку блокування';
$_['text_edit']        = 'Змінити заблокований IP';

// Column
$_['column_ip']        = 'IP';
$_['column_customer']  = 'Покупці';
$_['column_action']    = 'Дія';

// Entry
$_['entry_ip']         = 'IP';

// Error
$_['error_permission'] = 'У Вас немає доступу до зміни блокованих IP користувачів!';
$_['error_ip']         = 'IP повинен містити від 1 до 40 символів!';