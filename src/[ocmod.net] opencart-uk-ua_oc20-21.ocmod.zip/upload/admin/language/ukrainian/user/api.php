<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']        = 'API\'s';

// Text
$_['text_success']         = 'Ви успішно змінили API\'s!';
$_['text_list']            = 'Список API';
$_['text_add']             = 'Додати API';
$_['text_edit']            = 'Змінити API';

// Column
$_['column_username']      = 'Ім`я користувача';
$_['column_status']        = 'Статус';
$_['column_date_added']    = 'Дата додавання';
$_['column_date_modified'] = 'Дата зміни';
$_['column_action']        = 'Дія';

// Entry
$_['entry_username']       = 'Ім`я користувача';
$_['entry_password']       = 'Пароль';
$_['entry_status']         = 'Статус';

// Error
$_['error_permission']     = 'У Вас немає доступу до зміни API\'s!';овинно м
$_['error_username']       = 'Ім`я користувача повинно містити від 3 до 20 символів!';
$_['error_password']       = 'API пароль повинен містити від 3 до 256 символів!';