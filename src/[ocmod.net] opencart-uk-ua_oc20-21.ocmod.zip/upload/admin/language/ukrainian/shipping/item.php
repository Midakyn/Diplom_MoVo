<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'За одиницю';

// Text
$_['text_shipping']    = 'Доставка';
$_['text_success']     = 'Ви успішно змінили доставку За одиницю!';
$_['text_edit']        = 'Змінити доставку За одиницю';

// Entry
$_['entry_cost']       = 'Вартість';
$_['entry_tax_class']  = 'Клас податків';
$_['entry_geo_zone']   = 'Гео зони';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'У Вас немає доступу до зміни доставки За одиницю!';