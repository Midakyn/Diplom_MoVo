<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Отримання в магазині';

// Text
$_['text_shipping']    = 'Доставка';
$_['text_success']     = 'Ви успішно змінили доставку Отримання в магазині!';
$_['text_edit']        = 'Змінити доску Отримання в магазині';

// Entry
$_['entry_geo_zone']   = 'Гео зони';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порялок сортування';

// Error
$_['error_permission'] = 'У Вас немає доступу до змінит доставки Отримання в магазині!';