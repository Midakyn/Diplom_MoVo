<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title'] = 'Вихід з облікового запису';

// Text
$_['text_message']  = '<p>Ви вийшли з облікового запису.</p>';
$_['text_account']  = 'Обліковий запис';
$_['text_logout']   = 'Вихід';