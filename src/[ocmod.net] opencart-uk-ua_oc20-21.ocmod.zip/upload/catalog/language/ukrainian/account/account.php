<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']      = 'Мій обліковий запис';

// Text
$_['text_account']       = 'Обліковий запис';
$_['text_my_account']    = 'Обліковий запис';
$_['text_my_orders']     = 'Замовлення';
$_['text_my_newsletter'] = 'Розсилання новин';
$_['text_edit']          = 'Редагувати обліковий запис';
$_['text_password']      = 'Змінити пароль';
$_['text_address']       = 'Змінити адреси Вашої адресної книги';
$_['text_wishlist']      = 'Змінити список бажаних товарів';
$_['text_order']         = 'Переглянути історію замовлень';
$_['text_download']      = 'Завантаження';
$_['text_reward']        = 'Бонусні бали';
$_['text_return']        = 'Переглянути запити на поверення';
$_['text_transaction']   = 'Транзакції';
$_['text_newsletter']    = 'Підписатися на/відмовитися від розсилання новин';
$_['text_recurring']     = 'Регулярні платежі';
$_['text_transactions']  = 'Транзакції';