<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']      = 'Ваші бонусні бали';

// Column
$_['column_date_added']  = 'Дата додавання';
$_['column_description'] = 'Опис';
$_['column_points']      = 'Бали';

// Text
$_['text_account']       = 'Обліковий запис';
$_['text_reward']        = 'Бонусні бали';
$_['text_total']         = 'Загальна кількість Ваших бонусних балів:';
$_['text_empty']         = 'У Вас немає бонусних балів!';