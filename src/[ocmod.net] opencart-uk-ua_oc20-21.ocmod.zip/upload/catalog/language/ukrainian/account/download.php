<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Завантаження облікового запису';

// Text
$_['text_account']      = 'Обліковий запис';
$_['text_downloads']    = 'Завантаження';
$_['text_empty']        = 'У вас немає замовлень, які можна завантажити!';

// Column
$_['column_order_id']   = 'Номер замовлення';
$_['column_name']       = 'Назва';
$_['column_size']       = 'Розмір';
$_['column_date_added'] = 'Дата додавання';