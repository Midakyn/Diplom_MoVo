<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Порівняння товарів';

// Text
$_['text_product']      = 'Деталі товарів';
$_['text_name']         = 'Товар';
$_['text_image']        = 'Зображення';
$_['text_price']        = 'Ціна';
$_['text_model']        = 'Модель';
$_['text_manufacturer'] = 'Бренд';
$_['text_availability'] = 'Наявність';
$_['text_instock']      = 'В наявності';
$_['text_rating']       = 'Рейтинг';
$_['text_reviews']      = 'За результатами %s оглядів.';
$_['text_summary']      = 'В загальному';
$_['text_weight']       = 'Вага';
$_['text_dimension']    = 'Розміри (Д x Ш x В)';
$_['text_compare']      = 'Порівняння товару (%s)';
$_['text_success']      = 'Ви успішно додали <a href="%s">%s</a> до вашого <a href="%s">порівняння товарів</a>!';
$_['text_remove']       = 'Ви успішно змінили Ваше порівняння товарів!';
$_['text_empty']        = 'Ви не обрали товарів для порівняння.';