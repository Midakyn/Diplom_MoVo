<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_title']    = 'Пошта Австралії';
$_['text_express']  = 'Експрес';
$_['text_standard'] = 'Стандартна';
$_['text_eta']      = 'днів';