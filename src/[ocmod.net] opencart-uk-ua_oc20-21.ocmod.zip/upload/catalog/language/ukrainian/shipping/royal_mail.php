<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_title']                 = 'Royal Mail';
$_['text_weight']                = 'Вага:';
$_['text_insurance']             = 'Застраховано до:';
$_['text_1st_class_standard']    = 'First Class Standard Post';
$_['text_1st_class_recorded']    = 'First Class Recorded Post';
$_['text_2nd_class_standard']    = 'Second Class Standard Post';
$_['text_2nd_class_recorded']    = 'Second Class Recorded Post';
$_['text_special_delivery_500']  = 'Special Delivery Next Day (&pound;500)';
$_['text_special_delivery_1000'] = 'Special Delivery Next Day (&pound;1000)';
$_['text_special_delivery_2500'] = 'Special Delivery Next Day (&pound;2500)';
$_['text_standard_parcels']      = 'Standard Parcels';
$_['text_airmail']               = 'Airmail';
$_['text_international_signed']  = 'International Signed';
$_['text_airsure']               = 'Airsure';
$_['text_surface']               = 'Surface';