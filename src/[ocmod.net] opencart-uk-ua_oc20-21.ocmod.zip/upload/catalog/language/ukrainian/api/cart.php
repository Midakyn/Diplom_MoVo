<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_success']     = 'Ви успішно змінили Вашого кошика!';

// Error
$_['error_permission'] = 'У Вас немає доступу до API!';
$_['error_stock']      = 'Товари позначені *** закінчилися або їхній залишок менший від кількості яку Ви хочете замовити!';
$_['error_minimum']    = 'Мінімальна кількість замовлення для %s становить %s!';
$_['error_store']      = 'Ви не можете купити цей продукт у цьому магазини!';
$_['error_required']   = '%s необхідно!';