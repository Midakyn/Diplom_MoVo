<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_success']     = 'Ви успішно використали купон на знижку!';

// Error
$_['error_permission'] = 'У Вас немає доступу до API!';
$_['error_coupon']     = 'Увага: купон неправильний, прострочений або закінчився ліміт для його використання!';