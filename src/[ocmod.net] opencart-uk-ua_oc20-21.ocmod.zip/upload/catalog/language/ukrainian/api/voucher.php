<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_success']     = 'Ви успішно використали знижку подарункового сертифікату!';
$_['text_cart']        = 'Ви успішно змінили Кошик!';

$_['text_for']         = '%s Подарунковий сертифікат %s';

// Error
$_['error_permission'] = 'У Вас немає доступу до API!';
$_['error_voucher']    = 'Подарунковий сертифікат недійсний або уже використаний!';
$_['error_to_name']    = 'Ім`я одержувача повинно містити від 1 до 64 символів!';
$_['error_from_name']  = 'Ваше ім`я повинно містити від 1 до 64 символів!';
$_['error_email']      = 'Неправильний E-Mail!';
$_['error_theme']      = 'Вкажіть тему!';
$_['error_amount']     = 'Сума повинна бути від %s і до %s!';