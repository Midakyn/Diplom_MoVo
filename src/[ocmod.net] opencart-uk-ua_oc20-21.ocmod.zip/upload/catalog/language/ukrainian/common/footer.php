<?php

// Text
$_['text_information']  = 'Інформація';
$_['text_service']      = 'Сервісні служби';
$_['text_extra']        = 'Додатково';
$_['text_contact']      = 'Контакти';
$_['text_return']       = 'Повернення';
$_['text_sitemap']      = 'Мапа сайту';
$_['text_manufacturer'] = 'Бренди';
$_['text_voucher']      = 'Подарункові сертифікати';
$_['text_affiliate']    = 'Партнерська програма';
$_['text_special']      = 'Спеціальні пропозиції';
$_['text_account']      = 'Обліковий запис';
$_['text_order']        = 'Історія замовлень';
$_['text_wishlist']     = 'Список побажань';
$_['text_newsletter']   = 'Розсилання новин';
if (isset($_SERVER['REQUEST_URI']) && trim($_SERVER['REQUEST_URI'], '/') == '') {
    $_['text_powered'] = '<a href="https://ocmod.net/ua/moduli/" target="_blank">OpenCart</a><br> %s &copy; %s';
} else {
    $_['text_powered'] = 'OpenCart<br> %s &copy; %s';
}