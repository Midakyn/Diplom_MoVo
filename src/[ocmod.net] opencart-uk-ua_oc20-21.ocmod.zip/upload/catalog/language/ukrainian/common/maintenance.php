<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Сайт на технічному обсліговуванні';

// Text
$_['text_maintenance'] = 'Сайт знаходиться на технічному обслуговуванні';
$_['text_message']     = '<h1 style="text-align:center;">В дания час ми проводимо планове технічне обслугоування. <br/>Сайт скоро відновить свою роботу. Будь-ласка зайдіть через деякий час.</h1>';