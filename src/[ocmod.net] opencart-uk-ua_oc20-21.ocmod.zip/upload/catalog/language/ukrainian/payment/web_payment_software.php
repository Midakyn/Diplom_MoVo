<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_title']				= 'Кредитна / Дебетна карта (Web Payment Software)';
$_['text_credit_card']			= 'Деталі кредитної карти';

// Entry
$_['entry_cc_owner']			= 'Власник карти';
$_['entry_cc_number']			= 'Номер карти';
$_['entry_cc_expire_date']		= 'Дійсна до';
$_['entry_cc_cvv2']				= 'Код безпеки карти (CVV2)';