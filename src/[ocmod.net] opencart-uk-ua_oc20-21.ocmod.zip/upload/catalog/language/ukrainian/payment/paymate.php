<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_title']				= 'Кредитна / Дебетна карта (Paymate)';
$_['text_unable']				= 'Не вдалося знайти чи оновити статус замовлення';
$_['text_declined']				= 'Платіж відхилено сервісом Paymate';
$_['text_failed']				= 'Невдала оплата Paymate';
$_['text_failed_message']		= '<p>На жаль в процесі оплати Paymate виникла помилка.</p><p><b>Увага: </b>%s</p><p>будь-ласка перевірте Ваш Paymate баланс перед наступною стробою оплати цього замовлення</p><p> Якщо ви вважаєте що ця транзакція була успішною, чи гроші було списано з Вашого Paymate балансу, будь-ласка <a href="%s">напишіть нам</a> вказавши деталі Вашого замовлення.</p>';
$_['text_basket']				= 'Кошик';
$_['text_checkout']				= 'Оформити';
$_['text_success']				= 'Успішно';