<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']				= 'Дякуємо за покупку в %s .... ';

// Text
$_['text_title']				= 'Кредитна / Дебетна карта (WorldPay)';
$_['text_response']				= 'Відповідь від WorldPay:';
$_['text_success']				= '... Ваш платіж успішно отримано.';
$_['text_success_wait']			= '<b><span style="color: #FF0000">Зачекайте будь-ласка...</span></b> поки ми закінчимо обробляти Ваше замовлення.<br>Якщо протягом 10 секунд Ви не будете автоматично перенаправлені, будь-ласка натисніть <a href="%s">сюди</a>.';
$_['text_failure']				= '... Ваш платіж скасовано!';
$_['text_failure_wait']			= '<b><span style="color: #FF0000">Зачекайте будь-ласка...</span></b><br>Якщо протягом 10 секунд Ви не будете автоматично перенаправлені, будь-ласка натисніть <a href="%s">сюди</a>.';
$_['text_pw_mismatch']			= 'CallbackPW не співпадає. Замовлення буде переглянуто.';