<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_title']				= 'Кредитна чи дебетна карта';
$_['text_secure_connection']	= 'Створюємо безпечне з`єднання...';

// Error
$_['error_connection']			= 'Неможливо з`єднатися з PayPal. Будь-ласка зв`яжіться з адміністрацією магазину для підтримки або оберіть інший метод оплати.';