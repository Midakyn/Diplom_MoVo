<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_title']				= 'PayPal';
$_['text_reason']				= 'Причина';
$_['text_testmode']				= 'Увага: Платіжний шлюз працює в режимі \'Sandbox Mode\'. Оплата з Вашого балансу не буде зніматися.';
$_['text_total']				= 'Доставка, обробка, знижки і податки';