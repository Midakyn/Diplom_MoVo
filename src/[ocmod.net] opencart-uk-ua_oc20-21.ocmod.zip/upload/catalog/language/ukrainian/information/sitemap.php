<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Мапа сайту';

// Text
$_['text_special']     = 'Спеціальні пропозиції';
$_['text_account']     = 'Обліковий запис';
$_['text_edit']        = 'Інформація облікового запису';
$_['text_password']    = 'Пароль';
$_['text_address']     = 'Адресна книга';
$_['text_history']     = 'Історія замовлень';
$_['text_download']    = 'Завантаження';
$_['text_cart']        = 'Кошик';
$_['text_checkout']    = 'Оформити замовлення';
$_['text_search']      = 'Пошук';
$_['text_information'] = 'Інформація';
$_['text_contact']     = 'Контакти';