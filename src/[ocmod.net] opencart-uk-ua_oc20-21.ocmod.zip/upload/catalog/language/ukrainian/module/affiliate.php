<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Партнерська програма';

// Text
$_['text_register']    = 'Реєстрація';
$_['text_login']       = 'Вхід';
$_['text_logout']      = 'Вихід';
$_['text_forgotten']   = 'Забули пароль?';
$_['text_account']     = 'Обліковий запис';
$_['text_edit']        = 'Змінити обліковий запис';
$_['text_password']    = 'Пароль';
$_['text_payment']     = 'Варіанти оплати';
$_['text_tracking']    = 'Відслідковування партнерської програми';
$_['text_transaction'] = 'Оплати';
