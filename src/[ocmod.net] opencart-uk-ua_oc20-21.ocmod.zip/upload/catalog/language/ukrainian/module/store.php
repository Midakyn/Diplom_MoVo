<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title'] = 'Оберіть магазин';

// Text
$_['text_default']  = 'За замовчуванням';
$_['text_store']    = 'Будь-ласка, оберіть магазин, який Ви хочете відвідати.';