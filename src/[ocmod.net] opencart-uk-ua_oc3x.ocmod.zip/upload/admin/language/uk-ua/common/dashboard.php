<?php
// Heading
$_['heading_title'] = 'Панель управління';

// Error
$_['error_install'] = 'УВАГА: Установча папка досі існує! Видаліть папку install';