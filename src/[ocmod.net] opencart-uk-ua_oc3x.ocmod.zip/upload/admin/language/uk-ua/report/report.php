<?php
// Heading
$_['heading_title'] = 'Reports';

// Text
$_['text_success']  = 'Success: You have modified reports!';
$_['text_list']     = 'Report List';
$_['text_type']     = 'Choose the report type';
$_['text_filter']   = 'Filter';