<?php
// Heading
$_['heading_title'] = 'Журнал помилок';

// Text
$_['text_success'] = 'Журнал помилок очищений!';
$_['text_list'] = 'Помилки';

// Error
$_['error_warning'] = 'Увага: Ваш файл помилок %s is %s!';
$_['error_permission'] = 'У Вас немає прав для управління даним модулем!';