<?php
//$_[''] = '';
$_['text_filter'] = 'Фільтр';
$_['text_link'] = 'Зв&#39;язки';
$_['text_product'] = 'Товари';
$_['text_description'] = 'Опис';
$_['text_table'] = 'Таблицю';
$_['text_variable'] = 'Мінлива';
$_['text_language'] = 'Мова';
$_['text_variables'] = 'Змінні';
$_['text_multilanguage'] = 'Багатомовний';

$_['text_quick_filter'] = 'Швидкий фільтр';
$_['text_view_categories'] = 'Вид категорій';
$_['text_price_prefix'] = 'Дія з ціною';
$_['text_dir_image'] = 'Папка із зображеннями';

$_['text_column_categories'] = 'Колонка категорій';
$_['text_column_attributes'] = 'Колонка атрибутів';
$_['text_column_options'] = 'Колонка опцій';

$_['text_product_image_remove'] = 'Видаляти зображення <span class = "be-help"> при видаленні товарів </ span>';

$_['text_tab'] = 'Вкладка';
$_['text_list'] = 'Список';

$_['text_save'] = 'Зберегти';
$_['text_add'] = 'Додати';
$_['text_delete'] = 'Видалити';

$_['button_activate'] = 'Активувати';

$_['error_activate_extension'] = 'Модуль не активний!';
$_['error_link_table'] = 'Виберіть таблицю!';
$_['error_link_description'] = 'Введіть опис!';
$_['error_permission'] = 'У Вас немає прав для управління модулем Batch Editor!';

$_['Success_activate_extension'] = 'Модуль активний!';
$_['Success_delete_link'] = 'Зв&#39;язок успішно видалена!';
$_['Success_edit_link'] = 'Зв&#39;язок успішно збережена!';
?>