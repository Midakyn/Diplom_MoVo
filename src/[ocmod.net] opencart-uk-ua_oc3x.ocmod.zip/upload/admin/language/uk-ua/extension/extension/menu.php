<?php
// Heading
$_['heading_title']    = 'Меню';

// Text
$_['text_success']     = 'Успіх: Ви змінили меню!';
$_['text_list']        = 'Список меню';

// Column
$_['column_name']      = 'Назва меню';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Дія';

// Error
$_['error_permission'] = 'Попередження: у вас немає дозволу на змінення меню!';